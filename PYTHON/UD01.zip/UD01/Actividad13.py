'''Dibuja un ordinograma de un programa que muestre los números desde el 1 hasta el
número N que se introducirá por teclado.'''

N = int(input("Introduce el número N: "))
for i in range(1, N + 1):
    print(i)
