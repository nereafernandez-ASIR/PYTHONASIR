'''Dibuja un ordinograma que calcule y muestre el área de un cuadrado de lado igual a 5 (El
área del cuadrado es igual a lado por lado)'''
lado = 5
print('area = ', lado * lado)