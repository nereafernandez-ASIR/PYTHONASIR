'''Dibuja un ordinograma que dé las “Buenas Tardes”'''
print ("Buenas tardes")
