'''Dibuja un ordinograma de un programa que muestre los números pares comprendidos
entre el 1 y el 200. Para ello utiliza un contador y suma de 2 en 2''' 

i = 2
while i <= 200:
    print(i)
    i += 2
