'''Escriba un programa que lea dos números, calcule y muestre el valor de sus suma, resta,
producto y división'''

a = float(input("Introduce el primer número: "))
b = float(input("Introduce el segundo número: "))

print("Suma:", a + b)
print("Resta:", a - b)
print("Producto:", a * b)
print("División:", a / b)
