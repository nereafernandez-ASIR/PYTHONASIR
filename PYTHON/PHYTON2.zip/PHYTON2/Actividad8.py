'''Escriba un programa que pida la edad por teclado y nos muestra el mensaje de “Eres mayor
de edad”, si y solamente si lo somos'''

edad = int(input("Introduce tu edad: "))
if edad >= 18:
    print("Eres mayor de edad")
