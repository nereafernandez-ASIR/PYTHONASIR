'''Escriba un programa que calcule el área de un cuadrado cuyo lado se introduce por teclado
(El área del cuadrado es igual a lado por lado)'''

lado = float(input("Introduce el lado del cuadrado: "))
area = lado * lado
print("El área del cuadrado es:", area)
