'''Escribe un programa que dé las “Buenas tardes”.'''
print ('Buenas tardes')