'''Escriba un programa que lea un número y dice si es positivo o negativo, consideramos el
cero como positivo'''

n = float(input("Introduce un número: "))

if n >= 0:
    print("El número es positivo")
else:
    print("El número es negativo")
